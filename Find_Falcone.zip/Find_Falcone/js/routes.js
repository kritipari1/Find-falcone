// angular.module('myApp.routes',['ngRoute']);
	myApp.config(['$routeProvider', function($routeProvider){

		$routeProvider
		// .when('/#',{
		// 	templateUrl: 'partials/main.html',
		// 	controller: 'MainController',
		// 	controllerAs : 'mainCtrl'
		// })
		.when('/findFalcone',{
			templateUrl: 'partials/findFalcone.html',
			controller: 'MainController',
			  controllerAs : 'mainCtrl'
		})
		.when('/result',{
			templateUrl: 'partials/result.html',
			controller: 'MainController',
			controllerAs : 'mainCtrl'
		})
		.otherwise({
			redirectTo: '/findFalcone'
		})
	}])